These files in the 'SoundEffectsFX009' directory is
copyright 2014 by jalastram and is licensed under a
Creative Commons Attribution 3.0 Unported License:
  http://creativecommons.org/licenses/by/3.0/
